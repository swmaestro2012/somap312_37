# -*- coding: utf-8 -*-

from django.contrib.syndication.views import Feed
from django.utils import feedgenerator
from django.utils.feedgenerator import Rss201rev2Feed
from app.models import * 
from django.contrib.auth.models import User

class customfeed_game_request(Rss201rev2Feed):
    def add_item_elements(self, handler, item):
        super(customfeed_game_request, self).add_item_elements(handler, item)
        handler.addQuickElement(u"hostuser_id", item['hostuser_id'])
        handler.addQuickElement(u"hostuser_ip", item['hostuser_ip'])
        handler.addQuickElement(u"game_type", item['game_type'])
        
class customfeed_user_list(Rss201rev2Feed):
    def add_item_elements(self, handler, item):
        super(customfeed_user_list, self).add_item_elements(handler, item)
        handler.addQuickElement(u"username", item['username'])
        handler.addQuickElement(u"email", item['email'])

class customfeed_user_ext_info(Rss201rev2Feed):
    def add_item_elements(self, handler, item):
        super(customfeed_user_ext_info, self).add_item_elements(handler, item)
        handler.addQuickElement(u"int_field_1", item['int_field_1'])
        handler.addQuickElement(u"int_field_2", item['int_field_2'])
        handler.addQuickElement(u"int_field_3", item['int_field_3'])
        handler.addQuickElement(u"int_field_4", item['int_field_4'])
        handler.addQuickElement(u"string_field", item['string_field'])

class user_ext_info_feed(Feed):
    feed_type = customfeed_user_ext_info
    title = u'user extra information'
    link = '/feeds/get_user_ext_info/'
    description = u'user extra information'
    
    def get_object(self, request, username):
        return UserExtInfo.objects.filter(username=username).order_by('-id')[:10]
    
    def item_title(self, item):
        return item.username
    
    def item_description(self, item):
        return item.username
    
    def item_extra_kwargs(self, item):
        return{
               'int_field_1':str(item.intField1),
               'int_field_2':str(item.intField2),
               'int_field_3':str(item.intField3),
               'int_field_4':str(item.intField4),
               'string_field':str(item.stringField),
               }
        
    def items(self, user_ext_info):
        return user_ext_info
    
class friends_list_feed(Feed):
    feed_type = customfeed_user_list
    title = u'friends list'
    link = '/feeds/get_friends_list/'
    description = u'friends list'
    
    def get_object(self, request):
        return User.objects.order_by('-id')[:10]
    
    def item_title(self, item):
        return item.username
    
    def item_description(self, item):
        return item.email
    
    def item_extra_kwargs(self, item):
        return{
               'username':str(item.username),
               'email':str(item.email),
               }
        
    def items(self, game_req):
        return game_req 

class user_list_feed(Feed):
    feed_type = customfeed_user_list
    title = u'user list'
    link = '/feeds/get_user_list/'
    description = u'user list'
    
    def get_object(self, request):
        return User.objects.order_by('-id')[:10]
    
    def item_title(self, item):
        return item.username
    
    def item_description(self, item):
        return item.email
    
    def item_extra_kwargs(self, item):
        return{
               'username':str(item.username),
               'email':str(item.email),
               }
        
    def items(self, game_req):
        return game_req

class game_req_feed(Feed):
    feed_type = customfeed_game_request
    title = u'game request infomation'
    link = '/feeds/get_game_request/'
    description = u'game request infomation'
    
    def get_object(self, request, username):
        return GameRoom.objects.filter(invitePlayerID=username).order_by('-id')[:10]
    
    def item_title(self, item):
        return item.hostPlayerIP
    
    def item_description(self, item):
        return item.gameType
    
    def item_extra_kwargs(self, item):
        return{
               'hostuser_ip':str(item.hostPlayerIP),
               'game_type':str(item.gameType),
               'hostuser_id':str(item.hostPlayerID),
               #'game_id':str(item.id),
               }
        
    def items(self, game_req):
        return game_req

'''
class get_game_request(Feed):
    title = u'test feeds'
    link = '/feeds/recent/'
    description = u'test feeds'
    
    def get_absolute_url(self):
        return GameRoom.objects.order_by('-id')[:10]
'''