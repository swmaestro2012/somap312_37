from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.views.decorators.csrf import csrf_exempt
from app.models import GameRoom, UserExtInfo

import md5

from django.conf import settings
from django.template.response import TemplateResponse

try:
    from urllib.parse import urlparse, urlunparse
except ImportError:     # Python 2
    from urlparse import urlparse, urlunparse

# Avoid shadowing the login() and logout() views below.
from django.contrib.auth import REDIRECT_FIELD_NAME, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, PasswordResetForm, SetPasswordForm, PasswordChangeForm
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.models import get_current_site

@csrf_exempt                                   
def create_user_ext_info(request):    
    if request.method == 'POST':
        username = request.POST['username']
        intField1 = request.POST['int_field_1']
        intField2 = request.POST['int_field_2']
        intField3 = request.POST['int_field_3']
        intField4 = request.POST['int_field_4']
        stringField = request.POST['string_field']
        
        try:
            userExtInfo = UserExtInfo.objects.create(username = username, intField1 = intField1, intField2 = intField2, intField3 = intField3, intField4 = intField4, stringField = stringField)
        except Exception as e:
            return HttpResponse(e.args[0])
        
        return HttpResponse('200')

@csrf_exempt                                   
def create_multi_game(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[-1].strip()
    else:
        ip = request.META.get('HTTP_X_REAL_IP')
    
    if request.method == 'POST':
        invitePlayerID = request.POST['inviteuser_id']
        hostPlayerID = request.POST['hostuser_id']
        gameType = request.POST['game_type']
        hostPlayerIP = ip;
        
        try:
            gameroom = GameRoom.objects.create(invitePlayerID = invitePlayerID, gameType = gameType, hostPlayerIP = hostPlayerIP, hostPlayerID = hostPlayerID)
        except Exception as e:
            return HttpResponse(e.args[0])
        
        return HttpResponse('200')

@csrf_exempt
def game_account_create(request):
    if request.method == 'POST':
        companyName = request.POST['company_name']
        nickName = request.POST['nickname']
        try:
            gameroom = GameRoom.objects.create(companyName = companyName, nickName = nickName)
        except Exception as e:
            return HttpResponse(e.args[0])
        
        return HttpResponse('100')
    
    return HttpResponse('200')

def is_exist_company_name(request):
    return HttpResponse('200')

def is_exist_nickname(request):
    return HttpResponse('200')

'''
def get_user_list_using_post(request):
    reader = get_object_or_404(GameRoom)
    note_list = Note.objects.filter(user=reader)
    context = { 'reader': reader, 'note_list': note_list }
    return render_to_response('api/note_list.xml', context, context_instance=RequestContext(request), mimetype='application/xml')
'''


'''
@csrf_exempt
def send_multi_game_invite_msg(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[-1].strip()
    else:
        ip = request.META.get('REMOTE_ADDR')
    
    if request.method == 'POST':
        invitePlayerID = request.POST['invite_player_id']
        gameType = request.POST['game_type']
        hostPlyaerIP = ip;
        try:
            # add push msg code
            gameroom = GameRoom.objects.create(invitePlayerID = invitePlayerID, gameType = gameType, hostPlyaerIP = hostPlyaerIP)
        except Exception as e:
            return HttpResponse(e.args[0])
        
        return HttpResponse('100')

@csrf_exempt
def close_multi_game(request):
    if request.method == 'POST':
        gameID = request.POST['game_id']
        
        try:
            # add notify game end
            GameRoom.objects.get(id=id).delete()
        except Exception as e:
            return HttpResponse(e.args[0])
        
        return HttpResponse('100')

@csrf_exempt
def reject_game_request(request):
    if request.method == 'POST':
        gameID = request.POST['game_id']

    try:
        # add notify game end
        GameRoom.objects.get(id=id).delete()
    except Exception as e:
        return HttpResponse(e.args[0])
        
    return HttpResponse('100')

@csrf_exempt
def join_game_request(request):
    if request.method == 'POST':
        gameID = request.POST['game_id']

    try:
        # add notify game end
        GameRoom.objects.get(id=id).delete()
    except Exception as e:
        return HttpResponse(e.args[0])    
    
    return HttpResponse('100')
'''

@csrf_exempt                                   
def registration(request):
    if request.method == 'POST':
        username = request.POST['username']
        #password = md5.md5(request.POST['password']).hexdigest()
        password = request.POST['password']
        email = request.POST['email']
        
        try:
            user = User.objects.create_user(
                                            username=username,
                                            password=password,
                                            email=email
                                            )
        except:
            return HttpResponse('101')
        
        return HttpResponse('200')
    
    else:
        return HttpResponse('get!')
    
def login(request, template_name='registration/login.html',
          redirect_field_name='',
          authentication_form=AuthenticationForm,
          current_app=None, extra_context=None):
    """
    Displays the login form and handles the login action.
    """ 
    redirect_to = request.REQUEST.get(redirect_field_name, '')
    
    if request.method == "POST":
        form = authentication_form(data=request.POST)
        
        if form.is_valid():
            
            netloc = urlparse(redirect_to)[1]

            # Use default setting if redirect_to is empty
            if not redirect_to:
                redirect_to = settings.LOGIN_REDIRECT_URL

            # Heavier security check -- don't allow redirection to a different
            # host.
            elif netloc and netloc != request.get_host():
                redirect_to = settings.LOGIN_REDIRECT_URL

            # Okay, security checks complete. Log the user in.
            auth_login(request, form.get_user())

            if request.session.test_cookie_worked():
                request.session.delete_test_cookie()
            return HttpResponse('200')
        
        return HttpResponse('110')
                
    else:
        form = authentication_form(request)

    request.session.set_test_cookie()

    current_site = get_current_site(request)

    context = {
        'form': form,
        redirect_field_name: redirect_to,
        'site': current_site,
        'site_name': current_site.name,
    }
    if extra_context is not None:
        context.update(extra_context)
        
    return HttpResponse('101')


@csrf_exempt
def logout(request, next_page=None,
           template_name='registration/logged_out.html',
           redirect_field_name=REDIRECT_FIELD_NAME,
           current_app=None, extra_context=None):
    """
    Logs out the user and displays 'You are logged out' message.
    """
    auth_logout(request)
    return HttpResponse('200')

    redirect_to = request.REQUEST.get(redirect_field_name, '')
    if redirect_to:
        netloc = urlparse(redirect_to)[1]
        # Security check -- don't allow redirection to a different host.
        if not (netloc and netloc != request.get_host()):
            return HttpResponseRedirect(redirect_to)

    if next_page is None:
        current_site = get_current_site(request)
        context = {
            'site': current_site,
            'site_name': current_site.name,
            'title': _('Logged out')
        }
        if extra_context is not None:
            context.update(extra_context)
        return TemplateResponse(request, template_name, context,
                                current_app=current_app)
    else:
        # Redirect to this page until the session has been cleared.
        return HttpResponseRedirect(next_page or request.path)

'''
@csrf_exempt                                   
def register_page(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                                            username=form.cleaned_data['username'],
                                            password=form.cleaned_data['password1'],
                                            email=form.cleaned_data['email']
                                            )
            return HttpResponseRedirect('/register/success/')
    else:
        form = RegistrationForm()

    variables = RequestContext(request, {
                                         'form': form
                                         })
    return render_to_response('registration/register.html', variables)
'''