from django.db import models
from django.contrib.auth.models import User
from django.db.models.fields.related import ForeignKey
from django.db.models.base import Model

'''
class Friend(models.Model):
    
    def __unicode__(self):
        return '%s' % (self.hostPlyaerIP)
    
    def get_absolute_url(self):
        return self.hostPlyaerIP
'''

class Friendship(models.Model):
    created = models.DateTimeField(auto_now_add=True, editable=False)
    creator = models.ForeignKey(User, related_name="friendship_creator_set")
    friend = models.ForeignKey(User, related_name="friend_set")
    
    def __unicode__(self):
        return '%s' % (self.friend)
    
    def get_absolute_url(self):
        return self.friend

class GameRoom(models.Model):
    gameType = models.TextField()
    hostPlayerIP = models.TextField()
    hostPlayerID = models.TextField()
    invitePlayerID = models.TextField()
    #hostPlayerID = models.ForeignKey(User, related_name='host')
    #clientPlayerID = models.ForeignKey(User, related_name='client')
    
    def __unicode__(self):
        return '%s' % (self.hostPlayerIP)
    
    def get_absolute_url(self):
        return self.hostPlayerIP
    
class UserExtInfo(models.Model):
    username = models.TextField()
    intField1 = models.IntegerField()
    intField2 = models.IntegerField()
    intField3 = models.IntegerField()
    intField4 = models.IntegerField()
    stringField = models.TextField()
    
    def __unicode__(self):
        return '%s' % (self.username)
    
    def get_absolute_url(self):
        return self.username