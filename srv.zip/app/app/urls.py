from django.conf.urls import patterns, include, url
from django.views.generic.simple import direct_to_template
from django.contrib.syndication.views import *
from app.views import *
from app.feeds import *
from django.contrib.auth.views import login

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()
'''
feeds = {
         'get_game_request': game_req_feed
         }
'''

urlpatterns = patterns('',
                       #(r'^login/$', login),
                       (r'^login/$', 'django.contrib.auth.views.login'),
                       (r'^login2/$', csrf_exempt(login), {"template_name": "registration/login.html"}, "login"),
                       (r'^login3/$', 'django.contrib.auth.views.login'),
                       (r'^logout/$', logout),
                       (r'^test_static/$', direct_to_template, {'template': 'test_static.html'}),
                       (r'^create_rhythmgame/$', create_multi_game),
                       # Feeds
                       (r'^feeds/get_user_list/$', user_list_feed()),
                       (r'^feeds/get_game_request/$', game_req_feed()),
                       (r'^feeds/get_invite_list/(?P<username>\w+)/$', game_req_feed()),
                       (r'^feeds/get_user_ext_info/(?P<username>\w+)/$', user_ext_info_feed()),
                       (r'^registration/$', registration),
                       (r'^create_user_ext_info/$', create_user_ext_info),
                       
                       '''
                       (r'^feeds/(?P<url>.*)/$',
                        'django.contrib.syndication.views.Feed', 
                        {'feed_dict': feeds}),
                        '''
                        
                        
    # Examples:
    # url(r'^$', 'app.views.home', name='home'),
    # url(r'^app/', include('app.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
)
